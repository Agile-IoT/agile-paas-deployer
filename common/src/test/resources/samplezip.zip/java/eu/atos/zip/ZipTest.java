package eu.atos.zip;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.testng.annotations.Test;

public class ZipTest {

    @Test
    public void unzip() throws IOException {

        Path from = new File(ZipTest.class.getResource("/samplezip.zip").getFile()).toPath();
        Path to = Files.createTempDirectory("pul");
        
        System.out.println("unzipping to " + to);
        Zip.unzip(from, to);
    }
}
